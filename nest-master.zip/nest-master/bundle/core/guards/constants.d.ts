export declare const FORBIDDEN_MESSAGE = "Forbidden resource";
