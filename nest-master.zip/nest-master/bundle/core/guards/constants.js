"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FORBIDDEN_MESSAGE = 'Forbidden resource';
