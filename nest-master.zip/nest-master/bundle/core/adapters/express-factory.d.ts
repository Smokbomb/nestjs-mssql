export declare class ExpressFactory {
    static create(): any;
}
