export declare const messages: {
    APPLICATION_START: string;
    APPLICATION_READY: string;
    MICROSERVICE_READY: string;
    UNKNOWN_EXCEPTION_MESSAGE: string;
};
export declare const APP_INTERCEPTOR = "APP_INTERCEPTOR";
export declare const APP_PIPE = "APP_PIPE";
export declare const APP_GUARD = "APP_GUARD";
export declare const APP_FILTER = "APP_FILTER";
