import { RequestMethod } from '@nestjs/common/enums/request-method.enum';
export declare class RouterMethodFactory {
    get(target: any, requestMethod: RequestMethod): any;
}
