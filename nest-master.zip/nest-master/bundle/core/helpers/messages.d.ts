export declare const moduleInitMessage: (module: string) => string;
export declare const routeMappedMessage: (path: string, method: any) => string;
export declare const controllerMappingMessage: (name: string, path: string) => string;
