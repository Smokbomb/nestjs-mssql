import { Module } from './module';
export declare class ModulesContainer extends Map<string, Module> {
}
