export declare const HTTP_SERVER_REF = "HTTP_SERVER_REF";
