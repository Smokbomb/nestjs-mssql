"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ModulesContainer extends Map {
}
exports.ModulesContainer = ModulesContainer;
