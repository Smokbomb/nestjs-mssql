import { RuntimeException } from './runtime.exception';
export declare class InvalidExceptionFilterException extends RuntimeException {
    constructor();
}
