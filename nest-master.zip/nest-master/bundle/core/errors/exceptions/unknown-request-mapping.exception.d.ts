import { RuntimeException } from './runtime.exception';
export declare class UnknownRequestMappingException extends RuntimeException {
    constructor();
}
