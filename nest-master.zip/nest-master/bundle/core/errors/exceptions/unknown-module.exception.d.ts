import { RuntimeException } from './runtime.exception';
export declare class UnknownModuleException extends RuntimeException {
    constructor();
}
