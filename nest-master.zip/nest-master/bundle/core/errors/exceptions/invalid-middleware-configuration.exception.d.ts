import { RuntimeException } from './runtime.exception';
export declare class InvalidMiddlewareConfigurationException extends RuntimeException {
    constructor();
}
