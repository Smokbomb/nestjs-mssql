import { RuntimeException } from './runtime.exception';
export declare class InvalidModuleException extends RuntimeException {
    constructor(trace: any[]);
}
