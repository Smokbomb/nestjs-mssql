import { RuntimeException } from './runtime.exception';
export declare class InvalidMiddlewareException extends RuntimeException {
    constructor(name: string);
}
