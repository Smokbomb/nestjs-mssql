import { RuntimeException } from './runtime.exception';
export declare class MicroservicesPackageNotFoundException extends RuntimeException {
    constructor();
}
