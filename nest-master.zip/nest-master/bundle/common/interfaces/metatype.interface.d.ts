export interface Metatype<T> {
    new (...args: any[]): T;
}
