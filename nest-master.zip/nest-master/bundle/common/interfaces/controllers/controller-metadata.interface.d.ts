export interface ControllerMetadata {
    path?: string;
}
