export declare type CustomParamFactory = (data, req) => any;
