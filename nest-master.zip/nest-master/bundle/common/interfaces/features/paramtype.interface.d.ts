export declare type Paramtype = 'body' | 'query' | 'param' | 'custom';
