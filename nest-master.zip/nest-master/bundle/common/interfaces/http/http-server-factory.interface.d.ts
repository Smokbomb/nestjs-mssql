export interface HttpServerFactory {
    createServer(Function: any): any;
}
