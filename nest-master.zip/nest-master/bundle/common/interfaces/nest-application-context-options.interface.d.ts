import { LoggerService } from '../services/logger.service';
export declare class NestApplicationContextOptions {
    logger?: LoggerService | boolean;
}
