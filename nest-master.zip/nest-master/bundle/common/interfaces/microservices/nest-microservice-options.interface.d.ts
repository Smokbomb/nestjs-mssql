import { NestApplicationContextOptions } from '../nest-application-context-options.interface';
export interface NestMicroserviceOptions extends NestApplicationContextOptions {
}
