export declare type FunctionMiddleware = (req?, res?, next?) => any;
