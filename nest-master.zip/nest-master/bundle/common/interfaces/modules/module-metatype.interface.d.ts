import { NestModule } from './nest-module.interface';
import { Metatype } from '../metatype.interface';
export interface NestModuleMetatype extends Metatype<NestModule> {
}
