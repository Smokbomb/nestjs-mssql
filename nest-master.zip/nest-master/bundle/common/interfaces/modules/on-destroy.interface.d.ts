export interface OnModuleDestroy {
    onModuleDestroy(): any;
}
