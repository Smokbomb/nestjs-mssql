export interface OnModuleInit {
    onModuleInit(): any;
}
