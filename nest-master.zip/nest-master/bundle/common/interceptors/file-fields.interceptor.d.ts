import { MulterField, MulterOptions } from '../interfaces/external/multer-options.interface';
export declare function FileFieldsInterceptor(uploadFields: MulterField[], options?: MulterOptions): any;
