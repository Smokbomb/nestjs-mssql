import { MulterOptions } from '../interfaces/external/multer-options.interface';
export declare function FilesInterceptor(fieldName: string, maxCount?: number, options?: MulterOptions): any;
