import { MulterOptions } from '../interfaces/external/multer-options.interface';
export declare function FileInterceptor(fieldName: string, options?: MulterOptions): any;
