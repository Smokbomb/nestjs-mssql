"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidModuleConfigMessage = (property) => `Invalid property '${property}' in @Module() decorator.`;
