export declare const InvalidModuleConfigMessage: (property: string) => string;
