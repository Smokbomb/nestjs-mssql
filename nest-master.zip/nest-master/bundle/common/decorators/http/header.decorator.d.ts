import 'reflect-metadata';
/**
 * Sets a response header.
 */
export declare function Header(name: string, value: string): MethodDecorator;
