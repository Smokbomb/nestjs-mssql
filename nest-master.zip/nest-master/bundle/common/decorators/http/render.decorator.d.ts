import 'reflect-metadata';
/**
 * Defines a template to be rendered by the controller.
 */
export declare function Render(template: string): MethodDecorator;
