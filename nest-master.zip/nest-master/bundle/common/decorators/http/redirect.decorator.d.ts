import 'reflect-metadata';
/**
 * Redirects request.
 */
export declare function Redirect(url: string): MethodDecorator;
