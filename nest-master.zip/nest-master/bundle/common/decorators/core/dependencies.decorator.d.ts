import 'reflect-metadata';
export declare function flatten(arr: any[]): any;
export declare const Dependencies: (...dependencies: any[]) => ClassDecorator;
