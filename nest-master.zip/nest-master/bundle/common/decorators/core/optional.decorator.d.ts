import 'reflect-metadata';
/**
 * Sets dependency as an optional one.
 */
export declare function Optional(): ParameterDecorator;
