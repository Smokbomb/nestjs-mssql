export declare function loadPackage(packageName: string, context: string): any;
