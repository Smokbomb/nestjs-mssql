export declare const randomStringGenerator: () => string;
