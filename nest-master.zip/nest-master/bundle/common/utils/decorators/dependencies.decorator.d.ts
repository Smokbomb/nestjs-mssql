import 'reflect-metadata';
export declare const Dependencies: (...dependencies: any[]) => ClassDecorator;
