export declare function extendArrayMetadata<T extends Array<any>>(key: string, metadata: T, target: any): void;
