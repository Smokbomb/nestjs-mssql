import { ForwardReference } from '../interfaces/modules/forward-reference.interface';
export declare const forwardRef: (fn: () => any) => ForwardReference<any>;
