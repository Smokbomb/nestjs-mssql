"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forwardRef = (fn) => ({
    forwardRef: fn,
});
