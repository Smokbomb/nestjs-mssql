export declare class InvalidModuleConfigException extends Error {
  constructor(property: string);
}
