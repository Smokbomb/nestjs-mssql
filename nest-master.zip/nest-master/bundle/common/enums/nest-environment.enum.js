"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var NestEnvironment;
(function (NestEnvironment) {
    NestEnvironment[NestEnvironment["RUN"] = 0] = "RUN";
    NestEnvironment[NestEnvironment["TEST"] = 1] = "TEST";
})(NestEnvironment = exports.NestEnvironment || (exports.NestEnvironment = {}));
