export declare enum NestEnvironment {
    RUN = 0,
    TEST = 1,
}
