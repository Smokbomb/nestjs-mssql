export declare enum RouteParamtypes {
    REQUEST = 0,
    RESPONSE = 1,
    NEXT = 2,
    BODY = 3,
    QUERY = 4,
    PARAM = 5,
    HEADERS = 6,
    SESSION = 7,
    FILE = 8,
    FILES = 9,
}
